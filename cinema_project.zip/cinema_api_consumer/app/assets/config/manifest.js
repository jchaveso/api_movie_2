//= link_directory ../stylesheets
//= link application.css
//= link core-scripts.js
//= link application.js
//= link avatar/demi.png