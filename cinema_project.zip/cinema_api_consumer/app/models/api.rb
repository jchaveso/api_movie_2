module Api
  def self.table_name_prefix
    'api_'
  end
end
