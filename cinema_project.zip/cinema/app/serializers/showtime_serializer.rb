class ShowtimeSerializer < ActiveModel::Serializer
  attributes :id, :display, :movie
end
