class User < ApplicationRecord
  has_many :bookings
end
